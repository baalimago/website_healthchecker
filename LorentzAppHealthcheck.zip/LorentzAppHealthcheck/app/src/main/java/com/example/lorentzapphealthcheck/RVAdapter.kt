package com.example.lorentzapphealthcheck

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RVAdapter(websites: List<Website>) : RecyclerView.Adapter<RVAdapter.WebsiteViewHolder>() {
    val websites: List<Website> = websites
    class WebsiteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val name = itemView.findViewById<TextView>(R.id.websiteName)
        val downSince = itemView.findViewById<TextView>(R.id.downSince)
        val healthIcon = itemView.findViewById<ImageView>(R.id.healthIcon)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WebsiteViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.service_health, parent, false)
        val pvh = WebsiteViewHolder(v)
        return pvh
    }

    override fun getItemCount(): Int {
        return websites.count()
    }

    override fun onBindViewHolder(holder: WebsiteViewHolder, pos: Int) {
        val ws = websites[pos]
        holder.name.text = (ws.name)
        if (ws.state == State.HEALTHY) {
            holder.healthIcon.setImageResource(R.drawable.baseline_check_24)
            holder.downSince.text = ""
        } else {
            holder.healthIcon.setImageResource(R.drawable.baseline_close_24)
            holder.downSince.text = ws.downSince.toString()
        }
    }

}