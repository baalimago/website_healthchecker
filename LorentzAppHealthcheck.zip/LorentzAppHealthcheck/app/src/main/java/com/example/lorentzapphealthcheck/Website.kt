package com.example.lorentzapphealthcheck

import java.util.Date

enum class State {
    HEALTHY,
    UNHEALTHY
}

class Website(val name: String, val url: String) {
    var state = State.UNHEALTHY
    var downSince = Date()
}