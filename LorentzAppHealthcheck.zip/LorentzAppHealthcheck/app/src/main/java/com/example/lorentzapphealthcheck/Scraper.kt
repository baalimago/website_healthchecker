package com.example.lorentzapphealthcheck

import android.app.NotificationManager
import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

class Scraper(context: Context, parameters: WorkerParameters) : Worker(context, parameters) {
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    override fun doWork(): Result {
        return Result.success()
    }

}