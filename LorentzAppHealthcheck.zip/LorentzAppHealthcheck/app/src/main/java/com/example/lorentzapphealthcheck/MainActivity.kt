package com.example.lorentzapphealthcheck

import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.work.PeriodicWorkRequest
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private val NOTIFICATION_CHANNEL_ID = "lorentz-app-health"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setupNotificationChannel();
        setupScrapingWork();

        setContentView(R.layout.activity_main)

        val rv = findViewById<RecyclerView>(R.id.recycler_view)
        rv.setHasFixedSize(true)

        val llm = LinearLayoutManager(applicationContext)
        rv.layoutManager = llm

        val websites = ArrayList<Website>()
        websites.add(Website("Redblue", "https://redblue.lorentz.app"))
        websites.add(Website("Klunk0", "https://klunk.lorentz.app"))
        websites.add(Website("Klunk1", "https://klunk.lorentz.app"))
        websites.add(Website("Klunk2", "https://klunk.lorentz.app"))
        websites.add(Website("Klunk3", "https://klunk.lorentz.app"))

        websites[0].state = State.HEALTHY

        val adapter = RVAdapter(websites)
        rv.adapter = adapter
    }

    private fun setupNotificationChannel() {
        val importance = NotificationManager.IMPORTANCE_HIGH
        val mChannel = NotificationChannel(NOTIFICATION_CHANNEL_ID, "lorentz.app health", importance)
        mChannel.description = "Tracks the health of the microservices running on lorentz.app"
        // Register the channel with the system. You can't change the importance
        // or other notification behaviors after this.
        val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(mChannel)
    }

    private fun setupScrapingWork() {
        val scrapeRequest = PeriodicWorkRequestBuilder<Scraper>(
            10, TimeUnit.MINUTES,
            5, TimeUnit.MINUTES)
            .setInputData(workDataOf(
                "WEBSITE_URL" to "https://lorentz.app"
            ))
            .addTag("scraper")
            .build();
        WorkManager.getInstance(applicationContext).enqueue(scrapeRequest);
    }
}